(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	jQuery(document).ready(function ($) {
		/*
		 * The loading-type select is native now.
		 *
		 * It used to be a select2 widget, configured with allowClear so an owner
		 * could empty a required setting, and with the placeholder "Select Button
		 * Action" - copy belonging to a different field. select2 was loaded, CSS
		 * and JS, for that one three-option list; both are gone with it.
		 */

		/*
		 * Show the loading-image row only when Font Awesome is on. Uses a class
		 * rather than .show()/.hide() so the state is expressed in the markup
		 * and survives anything else that touches inline styles. Bound on
		 * `change`, not `click`, so a keyboard toggle counts too - with `click`
		 * the row did not react to the spacebar.
		 */
		$(document).on('change', '#infinite_loader_enable_font_awesome', function () {
			$('.infinite_loader_image_wrapper').toggleClass('is-hidden', !$(this).is(':checked'));
		});

		/*
		 * The colour "Default" buttons are handled generically in admin.js: one
		 * delegated .infinite-loader-color-reset handler reads each native colour
		 * input's data-default and repaints the preview. That replaced five
		 * id-specific handlers here, and let the Load More and Load Previous forms
		 * carry distinct ids without a per-id copy each.
		 */

		var infinite_select_icon_for = $('.infinite_display_icon_popup');
		$(document).on('click', '.infinite_loader_select_fontawesome .infinite_select_icon',function(event) {
            event.preventDefault();
			infinite_select_icon_for = $(this);
			var $html = $('<div class="infinite_loader_select_fontawesome"></div>');
			$html.append($('.infinite_display_icon_popup'));
            var $html2 = $('<div class="infinite_loader_icons_display icons_popup_body_area"></div>');
            $html2.append($html);
			$('body').children('.icons_popup_body_area').remove();
            $('body').append($html2);
			$('.infinite_display_icon_popup').show();
        });
		$(document).on('mouseenter', '.infinite_loader_select_fontawesome .infinite_icon_hover', function() {
            var window_width = $(window).width();
            window_width = window_width / 2;
			var $this = $(this).parents('.infinite_fa_fa_icon');
            if( $this.offset().left < window_width ) {
				$this.find('.infinite_icon_preview').css({left: '0', right: 'initial'});
				$this.find('.infinite_icon_preview span').appendTo($this.find('.infinite_icon_preview'));
            } else {
				$this.find('.infinite_icon_preview').css({left: 'initial', right: '0'});
				$this.find('.infinite_icon_preview .fa').appendTo($this.find('.infinite_icon_preview'));
            }
        });
		$(document).on('click', '.infinite_loader_select_fontawesome .infinite_icon_hover',function(event) {
            event.preventDefault();
			var value = $(this).parents('.infinite_fa_fa_icon').first().find('.infinite_icon_preview span').text();
			$(infinite_select_icon_for).parents('.infinite_loader_select_fontawesome').find('.infinite_icon_value').val(value).trigger('change');
			$('.infinite_display_icon_popup').hide();
			if ( value ) {
				$(infinite_select_icon_for).parents('.infinite_loader_select_fontawesome').find('.infinite_selected_icon').html('<i class="fa '+value+'"></i>').show();
				$(infinite_select_icon_for).parents('.infinite_loader_select_fontawesome').find(".infinite_remove_icons").show();
			} else {
				$(infinite_select_icon_for).parents('.infinite_loader_select_fontawesome').find('.infinite_selected_icon').html('').hide();
				$(infinite_select_icon_for).parents('.infinite_loader_select_fontawesome').find(".infinite_remove_icons").hide();
			}
        });
		$(document).on('click', '.infinite_loader_select_fontawesome .infinite_default_icon',function(event) {
            event.preventDefault();
			$(this).parents('.infinite_loader_select_fontawesome').find('.infinite_selected_icon').html('<i class="fa fa-spinner"></i>');
			$(this).parents('.infinite_loader_select_fontawesome').find('.infinite_icon_value').val('fa-spinner').trigger('change');
        });
		$(document).on('keyup', '.infinite_loader_select_fontawesome .infinite_icons_search', function() {
			var $parent = $(this).parents('.infinite_loader_select_fontawesome').first();
            var value = $(this).val();
            value = value.replace(/\s+/g, '');
            value = value.toLowerCase();
            if( value.length >=1 ) {
				$parent.find('.infinite_fa_fa_icon').hide();
				$parent.find('.infinite_icon_preview span:contains("' + value + '")').parents('.infinite_fa_fa_icon').show();
            } else {
				$parent.find('.infinite_fa_fa_icon').show();
            }
        });
		$(document).on('click', '.infinite_loader_select_fontawesome .infinite_display_icon_popup',function(event) {
            event.preventDefault();
            $(this).hide();
        });
		$(document).on('click', '.infinite_loader_select_fontawesome .infinite_display_icon_popup .infinite_close_popup',function(event) {
            event.preventDefault();
			$(this).parents('.infinite_display_icon_popup').hide();
        });
		$(document).on('click', '.infinite_loader_select_fontawesome .infinite_icons_popup',function(event) {
            event.preventDefault();
            event.stopPropagation();
        });

		// The FAQ tab is native <details>/<summary> now, so it opens and closes
		// on its own - no accordion script, and it stays keyboard-accessible
		// without one.
	});
})( jQuery );
